% Step 1: Load Image
clear
close all
x = imread('barbara.png');
[x_height, x_width] = size(x);
figure
imshow(x)

% Step 2: Design FIR Linear Phase Minimax Filter
Wp = 0.15 * pi;
Ws = 0.2 * pi;
[nfir, f0, m0, w] = firpmord([Wp, Ws], [1, 0], [0.05, 0.05]);
b_fir = firpm(nfir, f0, m0, w);
figure
zplane(b_fir); % Show z-plane of the filter

% Step 3: Design FIR Minimum Phase Filter
[b, a] = eqtflength(b_fir, 1);
[z, p, k] = tf2zp(b, a);
len = length(z);
km = k;
z_minP = zeros(len, 1);
zMag = abs(z);

for i = 1:len
    if(zMag(i) > 1)
        z_minP(i) = 1 / conj(z(i));
        km = km * zMag(i);
    else
        z_minP(i) = z(i);
    end
end

[b_min, a_min] = zp2tf(z_minP, p, km);

% Step 4: Apply Filters on Image
f_fir = zeros(x_height, x_width);
f_fir_min = zeros(x_height, x_width);

for i = 1:x_height
    f_fir(i, :) = filtfilt(b_fir, 1, double(x(i, :)));
    f_fir_min(i, :) = filtfilt(b_min, a_min, double(x(i, :)));
end

% Step 5: Show Frequency Response and Filtered Image
[H_fir, w_fir] = freqz(b_fir);
[H_fir_min, w_fir_min] = freqz(b_min, a_min);

figure;
subplot(2, 1, 1);
plot(w_fir/pi, abs(H_fir), 'b', w_fir_min/pi, abs(H_fir_min), 'r');
title('Magnitude Response');
legend('FIR Linear Phase', 'FIR Minimum Phase');

subplot(2, 1, 2);
plot(w_fir/pi, unwrap(angle(H_fir)*2)/2, 'b', w_fir_min/pi, unwrap(angle(H_fir_min)*2)/2, 'r');
title('Phase Response');

% Show Filtered Image
figure;
subplot(2, 1, 1);
imshow(f_fir, []);
title('Filtered Image - FIR Linear Phase');

subplot(2, 1, 2);
imshow(f_fir_min, []);
title('Filtered Image - FIR Minimum Phase');
